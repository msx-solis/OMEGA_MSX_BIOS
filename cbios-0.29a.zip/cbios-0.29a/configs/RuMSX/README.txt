C-BIOS machine configurations for RuMSX
=========================================

Installation instructions:
1. Copy "CONFIG" subdirectory in the RuMSX installation directory.
2. Copy "cbios_main_msx*.rom", "cbios_sub.rom" and "cbios_music.rom" into the
   "SYSTEM" directory.
